"""Init for ``cltk.dependency``."""

from .processes import *
from .tree import *
