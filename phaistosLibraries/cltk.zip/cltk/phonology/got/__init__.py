"""Gothic phonology
"""
