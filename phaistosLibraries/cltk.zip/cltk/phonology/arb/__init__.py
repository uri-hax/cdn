"""Classical Arabic phonology
"""
