"""Init for data modules."""
