"""Ancient Greek phonology
"""
