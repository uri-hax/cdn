"""Processes for phonology.
"""

from cltk.phonology.syllabifier_processes import *
from cltk.phonology.transcription_processes import *
