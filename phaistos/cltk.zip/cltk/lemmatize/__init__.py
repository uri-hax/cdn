"""Init for `cltk.lemmatize`."""

from .processes import *
