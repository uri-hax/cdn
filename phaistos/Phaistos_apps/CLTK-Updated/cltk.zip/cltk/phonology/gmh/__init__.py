"""Middle High German phonology
"""
