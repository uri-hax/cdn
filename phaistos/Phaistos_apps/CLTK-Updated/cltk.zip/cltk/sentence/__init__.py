from cltk.sentence.processes import (
    OldNorseSentenceTokenizationProcess,
    SentenceTokenizationProcess,
)
