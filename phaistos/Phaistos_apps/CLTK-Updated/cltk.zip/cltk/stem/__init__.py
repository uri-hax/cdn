"""Init for `cltk.tokenize`."""

from .processes import *
