"""Init for ``cltk.embeddings``."""

from .embeddings import *
from .processes import *
